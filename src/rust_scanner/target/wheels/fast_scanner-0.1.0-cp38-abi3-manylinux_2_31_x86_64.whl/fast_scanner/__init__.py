from .fast_scanner import *

__doc__ = fast_scanner.__doc__
if hasattr(fast_scanner, "__all__"):
    __all__ = fast_scanner.__all__